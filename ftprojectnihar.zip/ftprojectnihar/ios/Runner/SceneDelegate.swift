import Flutter
import UIKit

class SceneDelegate: FlutterSceneDelegate {

}
