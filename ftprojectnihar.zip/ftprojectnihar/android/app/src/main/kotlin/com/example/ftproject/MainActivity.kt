package com.example.ftproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
